/*
    Simpletron system developed by @Arose-Niazi
    Runner File.
    Started on: 28/9/2020
 */

/*
 * Includes
 */
#include "simple.h"

/*
    Main Function!
*/

int main(int counter, char *values[]) {
    runSimpletron(values[1]);
    return 0;
}

