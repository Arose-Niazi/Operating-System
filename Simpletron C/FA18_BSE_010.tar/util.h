//
// Created by arose on 02/10/2020.
//

#ifndef util_included
	#define util_included

FILE * loadFile(const char filename[]);

#endif //Using this so multiple includes can be ignored.