// Author : Arose Sibram Khan Niazi FA18_BSE_010

#include <stdio.h>
#include "myheader.h"

int main(void)
{
	printf("%-4s: %s\n"
		"%-4s: %s\n\n",
		"Name",NAME,"SID",SID);
	return 1;
}