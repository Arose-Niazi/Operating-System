import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ProcSim {

    private static File file;
    private static int algorithm;

    private static int cores;
    private static int processes;
    private static LinkedList<Process> processInfo;

    public static void main(String[] args)
    {
        if(args.length != 2)
        {
            System.err.println("Please enter filename and algorithm type as command line argument."
                    + "\n1 - First Come First Serve\n2 - Shortest Job First\n3 - Priority Based");
            return;
        }

        file = new File(args[0]);
        algorithm = Integer.parseInt(args[1]);

        if(!file.canRead())
        {
            System.err.println("Can not read the file.");
            return;
        }

        readFile();
        simulate();
    }

    private static void readFile()
    {
        try
        {
            Scanner input = new Scanner(file);
            cores = input.nextInt();
            processes = input.nextInt();
            processInfo = new LinkedList<>();
            for(int i=0; i<processes; i++)
            {
                Process process = new Process(input.nextInt(), input.nextInt(), input.nextInt(), input.nextInt());
                processInfo.add(process);
            }
        }
        catch (FileNotFoundException e)
        {
            System.err.println("File not found.");
        }
        catch (NoSuchElementException e)
        {
            System.err.println("File format incorrect, please recheck the file."
                    + "\nFormat should be: \n\tCores\n\tProcesses\n\tProcess ID\tArrival Time\tBurst Time\tPriority");
        }
    }

    private static void simulate()
    {
        CPUAlgo.setValues(processInfo);
        LinkedList<CPUAlgo> myCores = new LinkedList<>();
        switch (algorithm)
        {
            case 1:
            {
                for(int i = 0; i<cores; i++)
                    myCores.add(new FCFS());
                break;
            }
            case 2:
            {
                for(int i = 0; i<cores; i++)
                    myCores.add(new SJF());
                break;
            }
            case 3:
            {
                for(int i = 0; i<cores; i++)
                    myCores.add(new Priority());
                break;
            }
            default:
            {
                System.err.println("Invalid algorithm option."
                            + "\n1 - First Come First Serve\n2 - Shortest Job First\n3 - Priority Based");
                return;
            }
        }
        while (!CPUAlgo.getProcessInfo().isEmpty())
        {
            for(Process process: CPUAlgo.getProcessInfo()) {
                process.passTime();
            }
            for (CPUAlgo core : myCores) {
                core.passTime();
                core.selectProcess();
            }
        }
        CPUAlgo.printInfo();
    }
}

abstract class CPUAlgo {
    private static LinkedList<Process> processInfo;
    private static LinkedList<Process> allProcesses;
    private Process process;

    private static String algorithm;

    public Comparator<Process> comparator;

    public static void setValues(LinkedList<Process> pi)
    {
        setProcessInfo(pi);
        allProcesses = new LinkedList<>(pi);
    }

    void passTime()
    {
        if(getProcess() != null)
        {
            if(!getProcess().isLoaded())
            {
                getProcessInfo().remove(getProcess());
                setProcess(null);
            }
        }
    }

    public void selectProcess()
    {
        if(getProcess() == null)
        {
            for(Process process: getProcessInfo()) {
                if(!process.isCompleted() && !process.isLoaded())
                {
                    if(process.getArrivalTime() == 0)
                    {
                        process.setLoaded(true);
                        setProcess(process);
                        break;
                    }
                }

            }
        }
    }

    public static void printInfo()
    {
        System.out.println(algorithm);
        System.out.println("Total Time waiting: " + getWaitingTime());
        System.out.println("Average turnaround time: " + getTurnAroundAvg());
    }

    public static LinkedList<Process> getProcessInfo() {
        return processInfo;
    }

    public static void setProcessInfo(LinkedList<Process> processInfo) {
        CPUAlgo.processInfo = processInfo;
    }

    private static int getWaitingTime()
    {
        int waitingTime=0;
        for (Process process: allProcesses) {
            waitingTime+=process.getWaitingTime();
        }
        return waitingTime;
    }

    private static int getTurnAroundTime()
    {
        int ptime=0;
        for (Process process: allProcesses) {
            ptime+=process.getTurnaroundTime();
        }
        return ptime;
    }

    private static float getTurnAroundAvg()
    {
        return (float) getTurnAroundTime() / (float) allProcesses.size();
    }

    public Process getProcess() {
        return process;
    }

    public void setProcess(Process process) {
        this.process = process;
    }

    public void setComparator(Comparator<Process> comparator) {
        this.comparator = comparator;
        Collections.sort(getProcessInfo(), comparator);
    }

    public static void setAlgorithm(String algorithm) {
        CPUAlgo.algorithm = algorithm;
    }
}

class FCFS extends CPUAlgo {

    public FCFS() {
        setAlgorithm("First come first serve");
        setComparator(new CompareProcess());
        selectProcess();
    }

    class CompareProcess implements Comparator<Process>
    {
        public int compare(Process p1, Process p2)
        {
            return Integer.compare(p1.getArrivalTime(), p2.getArrivalTime());
        }
    }
}

class SJF extends CPUAlgo {

    public SJF() {
        setAlgorithm("Shortest job first");
        setComparator(new CompareProcess());
        selectProcess();
    }

    class CompareProcess implements Comparator<Process>
    {
        public int compare(Process p1, Process p2)
        {
            int value = Integer.compare(p1.getBurstTime(), p2.getBurstTime());
            if(value == 0)
                value = Integer.compare(p1.getArrivalTime(), p2.getArrivalTime());
            return value;
        }
    }
}

class Priority extends CPUAlgo {

    public Priority() {
        setAlgorithm("Priority");
        setComparator(new CompareProcess());
        selectProcess();
    }

    class CompareProcess implements Comparator<Process>
    {
        public int compare(Process p1, Process p2)
        {
            int value = Integer.compare(p1.getPriority(), p2.getPriority());
            if(value == 0)
                value = Integer.compare(p1.getArrivalTime(), p2.getArrivalTime());
            return value;
        }
    }
}

class Process {
    private final int id;
    private int arrivalTime;
    private int burstTime;
    private final int priority;
    private int waitingTime;
    private int processTime;

    private boolean completed;
    private boolean loaded;

    public Process(int id, int arrivalTime, int burstTime, int priority) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        waitingTime = processTime = 0;
        loaded = false;
        completed = false;
    }

    public void passTime()
    {
        if(!completed)
        {
            if(loaded)
            {
                processTime++;
                if(--burstTime == 0)
                {
                    completed=true;
                    loaded=false;
                }
            }
            else
            {
                if(arrivalTime > 0)
                    arrivalTime--;
                else
                    waitingTime++;
            }

        }
    }

    public int getId() {
        return id;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public int getPriority() {
        return priority;
    }

    public int getWaitingTime() {
        return waitingTime;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public boolean isCompleted() {
        return completed;
    }

    public int getTurnaroundTime() {
        return processTime + waitingTime;
    }

}

